// Scope : Where to look for things
// Q. What is that we are looking for

// Javascript is a synchronous, single thread lang.

var count = 10;
var name = "iNeuron";
function abc() {
  var xyz = "hello world";
  console.log(xyz);
  function abcd() {}
}
abc();

// Code from Script.js
var a = 10;
var b = 20;

function ab() {
  var aa = 10;
  var bb = 20;
  console.log(aa + bb);
  function abc() {
    console.log("Hello Worl");
  }
  abc();
}
ab();
var c = 30;

// Script.js
// Hoisting : Accessing Something before it is decalred
console.log(name);
sum();
var name = "Anurag";
function sum() {
  console.log("Hello Sum");
}
