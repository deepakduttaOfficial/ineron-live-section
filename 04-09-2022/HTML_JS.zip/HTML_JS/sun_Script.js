// Exception Handling
// Syntax
/*
    try{

    }catch(err){
        
    }
    finally{

    }
*/

// try :  wrap up the code which can throw the error
// catch: write the code to do something when error occurs.
// finally: it will always executed

try {
  let firstname = "Anurag";
  console.log(firstname + " " + lastname);
} catch (e) {
  console.log(e.name);
  console.log(e.message);
} finally {
  console.log("Important Operation");
}
console.log("Hello World");

// throw
// Reference error
// Syntax error
// typerror

// Code from script.js
var count = 10;
var counttwo = 07;
function fullName() {
  var fname = "Anurag";
  var lname = "Tiwari";
  console.log(fname, lname);
}
fullName();
