const a = 10;
let b = 20;
console.log(b);
var c = 25;
console.log(a);
